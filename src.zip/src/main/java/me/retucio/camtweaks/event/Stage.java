package me.retucio.camtweaks.event;

public enum Stage {
    PRE,  // antes de que haya sucedido
    POST;  // después de que haya sucedido
}

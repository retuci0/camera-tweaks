package me.retucio.camtweaks.event.events.camtweaks;

import me.retucio.camtweaks.event.Event;

public class LoadClickGUIEvent extends Event {}
package me.retucio.camtweaks.module.modules;

import me.retucio.camtweaks.module.Module;

/** continúa en:
 * @see me.retucio.camtweaks.mixin.EntityMixin
 */

public class AntiInvis extends Module {

    public AntiInvis() {
        super("anti invis", "te permite ver a los jugadores invisibles");
    }
}

package me.retucio.camtweaks.util.interfaces;

import com.mojang.authlib.GameProfile;

public interface IChatHudLine {

    String smegma$getText();

    int smegma$getId();
    void smegma$setId(int id);

    GameProfile smegma$getSender();
    void smegma$setSender(GameProfile profile);
}
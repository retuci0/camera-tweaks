package me.retucio.camtweaks.util.interfaces;

public interface IChatHudLineVisible extends IChatHudLine {

    boolean smegma$isStartOfEntry();
    void smegma$setStartOfEntry(boolean start);
}
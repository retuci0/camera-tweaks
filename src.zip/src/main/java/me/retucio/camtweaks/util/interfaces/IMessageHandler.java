package me.retucio.camtweaks.util.interfaces;

import com.mojang.authlib.GameProfile;

public interface IMessageHandler {

    GameProfile smegma$getSender();
}
